#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/8/20 0020 10:57
# @Author  : 熊利宏
# @project : 项目名称
# @Email   : xionglihong@163.com
# @File    : __init__.py.py
# @IDE     : PyCharm

# 身份证效验
from xToolkit.xstring.collect import identity

# 手机号效验
from xToolkit.xstring.collect import cellphone

# 数字效验
from xToolkit.xstring.collect import figure

# 效验中文
from xToolkit.xstring.collect import characters
