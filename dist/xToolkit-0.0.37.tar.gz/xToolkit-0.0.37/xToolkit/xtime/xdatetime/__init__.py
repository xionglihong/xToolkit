#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/3/19 7:40
# @Author  : 熊利宏
# @project : 时间模块get
# @Email   : xionglihong@163.com
# @File    : __init__.py
# @IDE     : PyCharm
# @REMARKS : 时间模块的get方法

pass
