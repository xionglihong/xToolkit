#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/3/15 22:21
# @Author  : 熊利宏
# @project : 时间模块
# @Email   : xionglihong@163.com
# @File    : __init__.py
# @IDE     : PyCharm

from xToolkit.xtime.api import XTime

xtime = XTime()

__all__ = ["xtime"]
