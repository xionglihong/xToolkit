#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/3/19 6:51
# @Author  : 熊利宏
# @project : 手写数字识别
# @Email   : xionglihong@163.com
# @File    : __init__.py.py
# @IDE     : PyCharm
# @REMARKS : X工具集的字符串模块