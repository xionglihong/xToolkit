#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/3/19 7:07
# @Author  : 熊利宏
# @project : 字符串处理模块
# @Email   : xionglihong@163.com
# @File    : dispose.py
# @IDE     : PyCharm
# @REMARKS : 字符串的一些常用处理

# 字符串处理
class Dispose(object):
    """
    正常的一些常用处理
    """
    def __init__(self):
        pass
