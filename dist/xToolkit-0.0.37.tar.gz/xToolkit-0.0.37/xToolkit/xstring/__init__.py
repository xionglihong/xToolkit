#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/3/16 20:51
# @Author  : 熊利宏
# @project : 字符串模块
# @Email   : xionglihong@163.com
# @File    : __init__.py
# @IDE     : PyCharm
# @REMARKS : 字符串模块


from xToolkit.xstring.api import XString

xstring = XString()

__all__ = ["xstring"]
