这个库是python内置库的一个扩展库.把python的datetime,string,list,dist等数据结构重新进行了封装，扩展了部分功能．

- 适用对象：python工程师
- 作者：熊利宏
- 邮箱：xionglihong@163.com
有任何意见欢迎发送邮件，我们一起打造一个好用的python内置库的扩展库

##### 什么是xToolkit库？
库xToolkit的中文名字叫Ｘ工具集．是python内置库的一个扩展库.把python的datetime,string,list,dist等数据结构重新进行了封装，扩展了部分功能．

##### 操作文档
操作文档还在编辑中，请等待

##### 实例：
1.导入xToolkit库
```python
from xToolkit import xdatetime as xdt
```
2.判断时间格式时分正确
```
#验证时间格式
"验证格式 1988-07-20 是否错误{}".format(xdt.shape("1988-07-20"))
"验证格式 1988-07-88 是否错误{}".format(xdt.shape("1988-07-88"))
"验证格式 98787987 是否错误{}".format(xdt.shape("98787987"))
#返回值
True
False
False
```
3.获取时间起止
```
#获取时间起止
"当月第一天和最后一天:{}".format(xdt.start_and_end())
"下个月第一天和最后一天:{}".format(xdt.start_and_end(space=1))
"上个月第一天和最后一天:{}".format(xdt.start_and_end(space=-1))
"今年第一天和最后一天:{}".format(xdt.start_and_end(genre="Y"))
"明年第一天和最后一天:{}".format(xdt.start_and_end(genre="Y", space=1))
"去年第一天和最后一天:{}".format(xdt.start_and_end(genre="Y", space=-1))
#返回值：
当月第一天和最后一天:['2019-05-01', '2019-05-31']
下个月第一天和最后一天:['2019-06-01', '2019-06-30']
上个月第一天和最后一天:['2019-04-01', '2019-04-30']
今年第一天和最后一天:['2019-01-01', '2019-12-31']
明年第一天和最后一天:['2020-01-01', '2020-12-31']
去年第一天和最后一天:['2018-01-01', '2018-12-31']
```
4.获取当前时间
```
#输出现在时间
"{}".format(xdt.now())
#输出结果
2019-05-21T21:48:25.873016+08:00
```
5.格式化当前时间
```
#输出年月日时分秒
"{}".format(xdt.now().format("YYYY-MM-DD　HH:mm:ss"))
#输出结果
2019-05-21 21:48:25

#输出年月
"{}".format(xdt.now().format("YYYY-MM-DD"))
#输出结果
2019-05-21
```

_更多实例请参照参考文档_