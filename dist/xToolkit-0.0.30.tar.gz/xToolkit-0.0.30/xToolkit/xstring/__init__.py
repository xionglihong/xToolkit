#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/8/20 0020 10:57
# @Author  : 熊利宏
# @project : 项目名称
# @Email   : xionglihong@163.com
# @File    : __init__.py.py
# @IDE     : PyCharm

# 数据效验
from xToolkit.xstring.collect import verified
