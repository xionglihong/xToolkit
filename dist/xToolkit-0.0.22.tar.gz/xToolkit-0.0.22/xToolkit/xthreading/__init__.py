#!/usr/bin/env python
# encoding: utf-8
"""
@author: 熊利宏
@email:xionglihong@163.com
@phone：15172383635
@project: xToolkit
@file: 多线程实例化
@time: 2019-05-31 下午3:06
"""

from .expansion import xthreading