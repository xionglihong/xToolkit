#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/3/15 22:22
# @Author  : 熊利宏
# @project : xtoolkit 总基类
# @Email   : xionglihong@163.com
# @File    : __init__.py.py
# @IDE     : PyCharm

from .xtoolkit import XToolkit
