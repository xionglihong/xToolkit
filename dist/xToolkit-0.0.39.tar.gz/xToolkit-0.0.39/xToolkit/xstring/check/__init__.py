#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/3/19 6:51
# @Author  : 熊利宏
# @project : 字符串验证模块
# @Email   : xionglihong@163.com
# @File    : __init__.py
# @IDE     : PyCharm
# @REMARKS : 验证字符串格式

pass